#!/usr/bin/bash
while true; do sh /home/hiyo/.config/eww/update-workspaces.sh;sleep 1s;done
